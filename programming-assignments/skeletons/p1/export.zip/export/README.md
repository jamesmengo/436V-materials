# P1: The Cost of Natural Disasters

Todo: Cite any external resources and explain exactly what modifications you have made.

-   Skipped step 5 initially to come back to, did not end up having time to fully implement
